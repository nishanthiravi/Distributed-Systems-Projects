package edu.buffalo.cse.cse486586.simpledht;

/**
 * Created by nishanthi on 4/14/17.
 */

public class Node {
    String nodeId;
    String myPort;
    Node predecessor;
    Node successor;

    Node(String id,String port){
        nodeId = id;
        myPort = port;
        predecessor=null;
        successor=null;
    }
}
