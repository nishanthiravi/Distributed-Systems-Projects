package edu.buffalo.cse.cse486586.simpledht;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;
import java.util.*;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.util.Log;

import static android.content.ContentValues.TAG;

public class SimpleDhtProvider extends ContentProvider {

    static final int SERVER_PORT = 10000;

    static final String OriginatorNode = "11108";

    static  HashMap<String,String> nodeIdMap = new HashMap<String,String>();

    Node head = null;

    Node myNode = null;

    MatrixCursor mCursor = null;
    boolean singleQueryCompleted = false;
    boolean queryCompleted = false;
    boolean singleDeleteCompleted = false;
    boolean deleteCompleted = false;


    @Override
    public String getType(Uri uri) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        // TODO Auto-generated method stub
        return 0;
    }

    private void setNodeIdForEmulators() {

        nodeIdMap.put("11108","5554");
        nodeIdMap.put("11112","5556");
        nodeIdMap.put("11116","5558");
        nodeIdMap.put("11120","5560");
        nodeIdMap.put("11124","5562");
    }

    private String genHash(String input) throws NoSuchAlgorithmException {

        MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
        byte[] sha1Hash = sha1.digest(input.getBytes());
        Formatter formatter = new Formatter();
        for (byte b : sha1Hash) {
            formatter.format("%02x", b);
        }
        return formatter.toString();

    }

    private void insertIntoRing(String newNodeId, String newNodePort){

        Node prev = null;
        Node current = null;
        Node newNode = null;
        boolean joined = false;

        if(head != null && head.successor != head){

            newNode = new Node(newNodeId, newNodePort);
            //if new node is smaller than head, assign it as head
            if(newNodeId.compareTo(head.nodeId)<0){
                Node temp = head.predecessor;
                newNode.successor = head;
                newNode.predecessor = temp;
                temp.successor =  newNode;
                head.predecessor = newNode;
                head = newNode;
                joined = true;

            }

            Node temp = head;
            do{
                current = temp;
                prev = current.predecessor;

                //insert into middle of linked list
                if((newNodeId.compareTo(prev.nodeId))>0 && (newNodeId.compareTo(current.nodeId)<0)){
                    prev.successor = newNode;
                    newNode.predecessor = prev;
                    newNode.successor = current;
                    current.predecessor = newNode;
                    joined = true;
                    break;

                }else if((newNodeId.compareTo(prev.nodeId))>0 && (newNodeId.compareTo(current.nodeId)>0)){
                    temp = temp.successor;
                }else{
                    temp = temp.successor;
                }
            }while(temp != head);

            //insert into end of circular linked list
            if(!joined) {
                newNode = new Node(newNodeId, newNodePort);
                current.successor = newNode;
                newNode.predecessor = current;
                newNode.successor = head;
                head.predecessor = newNode;
            }

        }else {
            //only head is present in ring
            newNode = new Node(newNodeId, newNodePort);
            head.predecessor = newNode;
            head.successor = newNode;
            newNode.predecessor = head;
            newNode.successor = head;
            if (newNode.nodeId.compareTo(head.nodeId) < 0) {
                head = newNode;
            }
        }
    }

    @Override
    public boolean onCreate() {

        Context context = getContext();
        TelephonyManager tel = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
        final String myPort = String.valueOf((Integer.parseInt(portStr) * 2));
        setNodeIdForEmulators();

        try {

            if(myPort.equals(OriginatorNode)) {

                String nodeId = genHash(nodeIdMap.get(OriginatorNode));
                myNode = new Node(nodeId,OriginatorNode);
                myNode.predecessor = myNode;
                myNode.successor = myNode;
                head = myNode;

            }else if(head==null && !(myPort.equals(OriginatorNode))){

                String nodeId = genHash(nodeIdMap.get(myPort));
                myNode = new Node(nodeId,myPort);
                myNode.predecessor = myNode;
                myNode.successor = myNode;
                head = myNode;

            }

            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);

            new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, myPort);

        } catch (IOException e) {
            Log.e(TAG, e.toString());
            Log.e(TAG, "Can't create a ServerSocket");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        return true;
    }


    @Override
    public Uri insert(Uri uri, ContentValues values) {

        String key = values.getAsString("key");
        String value = values.getAsString("value");

        try {
            String keyId = genHash(key);
            Log.v(TAG, "insert request " +key+" hash code "+keyId);
            FileOutputStream outputStream;
            Context context = getContext();
            // if key is greater than predecessor and less than my Node or if I am the only node or my Node is less than predecessor and either key is greater than predecessor or less than my Node
            if(((keyId.compareTo(myNode.predecessor.nodeId)>0)&&(keyId.compareTo(myNode.nodeId))<=0)
                    || ((myNode.predecessor.nodeId.compareTo(myNode.nodeId)==0) && (myNode.successor.nodeId.compareTo(myNode.nodeId)==0))
                    ||((myNode.nodeId.compareTo(myNode.predecessor.nodeId)<0)&&((keyId.compareTo(myNode.nodeId)<0)||(keyId.compareTo(myNode.predecessor.nodeId)>0)))) {

                outputStream = context.openFileOutput(key, Context.MODE_PRIVATE);
                outputStream.write(value.getBytes());
                outputStream.close();
                Log.v(TAG, "inserted: "+values.toString());

            }else{
                //forward request to my successor node
                try {
                    Socket contentProviderSocket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                            Integer.parseInt(myNode.successor.myPort));
                    DataOutputStream contentProviderStream = new DataOutputStream(contentProviderSocket.getOutputStream());
                    DataInputStream contentProviderInputStream = new DataInputStream(contentProviderSocket.getInputStream());
                    contentProviderStream.writeUTF("3" + "!~!" + key + "!~!" + value + "!~!" + myNode.myPort);
                    if (contentProviderInputStream.readUTF().equals("insert request forwarded") || contentProviderInputStream.readUTF().equals("insert request completed")) {
                        contentProviderInputStream.close();
                        contentProviderStream.close();
                        contentProviderSocket.close();
                    }
                }catch(Exception e){
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "File write failed");
        }
        return uri;
    }


    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
                        String sortOrder) {

        queryCompleted=false;
        singleQueryCompleted=false;

        try {

            Log.v(TAG,"query request "+selection);
            FileInputStream inputStream;
            Context context = getContext();

            if(selection.equals("@")||(selection.equals("*") && ((myNode.predecessor.nodeId.compareTo(myNode.nodeId)==0) && (myNode.successor.nodeId.compareTo(myNode.nodeId)==0)))){
                String[] myList = context.fileList();
                String[] columnNames = new String[2];
                columnNames[0] = "key";
                columnNames[1] = "value";

                mCursor = new MatrixCursor(columnNames);

                for(int i=0;i<myList.length;i++){
                    Log.v(TAG,"context file "+myList[i]);
                    inputStream = context.openFileInput(myList[i]);
                    BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
                    String value;
                    if ((value = in.readLine()) != null) {
                        Log.v(TAG, "retrieved "+ value);
                        Object[] columnValues = new Object[2];
                        columnValues[0] = myList[i];
                        columnValues[1] = value;
                        mCursor.addRow(columnValues);
                    }
                }

                return mCursor;

            }else if(selection.equals("*")){

                String[] myList = context.fileList();
                String[] columnNames = new String[2];
                columnNames[0] = "key";
                columnNames[1] = "value";

                mCursor = new MatrixCursor(columnNames);

                for(int i=0;i<myList.length;i++){
                    Log.v(TAG,"context file "+myList[i]);
                    inputStream = context.openFileInput(myList[i]);
                    BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
                    String value;
                    if ((value = in.readLine()) != null) {
                        Log.v(TAG, "retrieved "+ value);
                        Object[] columnValues = new Object[2];
                        columnValues[0] = myList[i];
                        columnValues[1] = value;
                        mCursor.addRow(columnValues);
                    }
                }

                String keys=" ";
                String values=" ";

                try {

                    Socket contentProviderSocket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                            Integer.parseInt(myNode.successor.myPort));
                    DataOutputStream contentProviderStream = new DataOutputStream(contentProviderSocket.getOutputStream());
                    DataInputStream contentProviderInputStream = new DataInputStream(contentProviderSocket.getInputStream());
                    contentProviderStream.writeUTF("6" + "!~!" + myNode.myPort + "!~!" + keys + "!~!" + values);

                    if (contentProviderInputStream.readUTF().equals("query request forwarded") || contentProviderInputStream.readUTF().equals("query request completed")) {
                        contentProviderInputStream.close();
                        contentProviderStream.close();
                        contentProviderSocket.close();
                    }
                }catch(Exception e){
                    }

                    while (!queryCompleted) {

                    }

                /*try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }*/
                return mCursor;
            }

            String keyId = genHash(selection);

            if(((keyId.compareTo(myNode.predecessor.nodeId)>0)&&(keyId.compareTo(myNode.nodeId))<=0)
                    || ((myNode.predecessor.nodeId.compareTo(myNode.nodeId)==0) && (myNode.successor.nodeId.compareTo(myNode.nodeId)==0))
                    ||((myNode.nodeId.compareTo(myNode.predecessor.nodeId)<0)&&((keyId.compareTo(myNode.nodeId)<0)||(keyId.compareTo(myNode.predecessor.nodeId)>0)))){

                inputStream = context.openFileInput(selection);
                BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
                String value;
                if ((value = in.readLine()) != null) {
                    Log.v(TAG, "retrieved: "+selection + " " + value);
                    String[] columnNames = new String[2];
                    columnNames[0] = "key";
                    columnNames[1] = "value";
                    mCursor = new MatrixCursor(columnNames);
                    Object[] columnValues = new Object[2];
                    columnValues[0] = selection;
                    columnValues[1] = value;
                    mCursor.addRow(columnValues);
                }

                inputStream.close();

            } else{

                try{

                Socket contentProviderSocket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        Integer.parseInt(myNode.successor.myPort));
                DataOutputStream contentProviderStream = new DataOutputStream(contentProviderSocket.getOutputStream());
                DataInputStream contentProviderInputStream = new DataInputStream(contentProviderSocket.getInputStream());

                contentProviderStream.writeUTF("4" + "!~!" + selection + "!~!" + myNode.myPort);

                if(contentProviderInputStream.readUTF().equals("query request forwarded")||contentProviderInputStream.readUTF().equals("query request completed")){
                    contentProviderInputStream.close();
                    contentProviderStream.close();
                    contentProviderSocket.close();
                }
                }catch(Exception e){
                }

                while (!singleQueryCompleted) {

                }

                /*try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }*/
            }
        } catch (Exception e) {
            Log.e(TAG, "Error when reading from file");
        }

        //int size = mCursor.getCount();
        //Log.v(TAG,"cursor size "+size);
        return mCursor;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {

        Context context = getContext();
        boolean deleteFlag = false;
        deleteCompleted = false;
        singleDeleteCompleted = false;

        try {
            String keyId = genHash(selection);

            if(((keyId.compareTo(myNode.predecessor.nodeId)>0)&&(keyId.compareTo(myNode.nodeId))<=0)
                    || ((myNode.predecessor.nodeId.compareTo(myNode.nodeId)==0) && (myNode.successor.nodeId.compareTo(myNode.nodeId)==0))
                    ||((myNode.nodeId.compareTo(myNode.predecessor.nodeId)<0)&&((keyId.compareTo(myNode.nodeId)<0)||(keyId.compareTo(myNode.predecessor.nodeId)>0)))) {
                deleteFlag = context.deleteFile(selection);
            }
            else{

                try{

                    Socket contentProviderSocket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                            Integer.parseInt(myNode.successor.myPort));
                    DataOutputStream contentProviderStream = new DataOutputStream(contentProviderSocket.getOutputStream());
                    DataInputStream contentProviderInputStream = new DataInputStream(contentProviderSocket.getInputStream());

                    contentProviderStream.writeUTF("8" + "!~!" + selection + "!~!" + myNode.myPort);

                    if(contentProviderInputStream.readUTF().equals("delete request forwarded")||contentProviderInputStream.readUTF().equals("delete request completed")){
                        contentProviderInputStream.close();
                        contentProviderStream.close();
                        contentProviderSocket.close();
                    }
                }catch(Exception e){
                }

                while (!singleDeleteCompleted) {

                }

                /*try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }*/
            }

            if (selection.equals("@")||(selection.equals("*") && ((myNode.predecessor.nodeId.compareTo(myNode.nodeId)==0) && (myNode.successor.nodeId.compareTo(myNode.nodeId)==0)))) {
                String[] myList = context.fileList();
                for (int i = 0; i < myList.length; i++) {
                    deleteFlag = context.deleteFile(myList[i]);
                }
            } else if (selection.equals("*")) {

                String[] myList = context.fileList();
                for (int i = 0; i < myList.length; i++) {
                    deleteFlag = context.deleteFile(myList[i]);
                }

                try{
                Socket contentProviderSocket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        Integer.parseInt(myNode.successor.myPort));
                DataOutputStream contentProviderStream = new DataOutputStream(contentProviderSocket.getOutputStream());
                DataInputStream contentProviderInputStream = new DataInputStream(contentProviderSocket.getInputStream());

                contentProviderStream.writeUTF("9" + "!~!" + myNode.myPort + "!~!" );

                if(contentProviderInputStream.readUTF().equals("delete request forwarded")||contentProviderInputStream.readUTF().equals("delete request completed")){
                    contentProviderInputStream.close();
                    contentProviderStream.close();
                    contentProviderSocket.close();
                }
                }catch(Exception e){
                }

                while (!deleteCompleted) {

                }

                /*try {
                    Thread.sleep(10000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }*/
            }
        } catch(Exception e){
            Log.e(TAG, "Error when deleting file");
        }

        if(deleteFlag || deleteCompleted ||singleDeleteCompleted)
            return 1;
        else
            return 0;
    }


    private class ServerTask extends AsyncTask<ServerSocket, String, Void> {

        @Override
        protected Void doInBackground(ServerSocket... sockets) {
            ServerSocket serverSocket = sockets[0];
            String msgReceived = null;
            String msgStrings[] = null;

                try {
                    while (true) {

                        Socket socket1 = null;
                        Socket socket2 = null;
                        //Server socket listens for any connection made to this socket
                        Socket outputSocket = serverSocket.accept();
                        //read the message sent over the socket using DataInputStream object
                        DataInputStream serverIn = new DataInputStream(outputSocket.getInputStream());

                        DataOutputStream serverOut = new DataOutputStream(outputSocket.getOutputStream());

                        if((msgReceived = serverIn.readUTF())!= null){

                            Log.v(TAG,"message received "+msgReceived);
                            msgStrings = msgReceived.split("!~!");
                        }

                        if(msgStrings[0].equals("1")){

                            Log.v(TAG,"message type 1-node join request");
                            String newNodeId = msgStrings[1];
                            String newNodePort = msgStrings[2];

                            insertIntoRing(newNodeId,newNodePort);

                            Node temp = head;

                            DataOutputStream serverOut1 = null;

                            do{

                                if(temp.myPort != OriginatorNode) {
                                     socket1 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                            Integer.parseInt(temp.myPort));
                                     serverOut1 = new DataOutputStream(socket1.getOutputStream());
                                    DataInputStream serverIn1 = new DataInputStream(socket1.getInputStream());

                                    serverOut1.writeUTF("2" + "!~!" + temp.predecessor.myPort + "!~!" + temp.successor.myPort);
                                    String ack1 = null;
                                    try {
                                        if ((ack1 = serverIn1.readUTF()).equals("Neighbours updated")) {
                                            serverIn1.close();
                                            serverOut1.close();
                                            socket1.close();
                                        }
                                    }catch(Exception e){
                                    }
                                }
                                temp = temp.successor;
                            }while(temp!=head);

                            serverOut.writeUTF("Node Joined");

                        }

                        if(msgStrings[0].equals("2")){

                                String predecessorPort = msgStrings[1];
                                String predecessorId = genHash(nodeIdMap.get(predecessorPort));
                                Node prev = new Node(predecessorId,predecessorPort);
                                myNode.predecessor = prev;


                                String successorPort = msgStrings[2];
                                String successorId = genHash(nodeIdMap.get(successorPort));
                                Node next = new Node(successorId, successorPort);
                                myNode.successor = next;

                                serverOut.writeUTF("Neighbours updated");

                                serverOut.close();
                                outputSocket.close();
                        }

                        if(msgStrings[0].equals("3")){

                            Log.v(TAG,"message type 3-routed insert request");

                            String key = msgStrings[1];
                            String value = msgStrings[2];
                            String requestorPort = msgStrings[3];
                            String keyId = genHash(key);

                            if(((keyId.compareTo(myNode.predecessor.nodeId)>0)&&(keyId.compareTo(myNode.nodeId))<=0)
                            || ((myNode.nodeId.compareTo(myNode.predecessor.nodeId)<0)&&((keyId.compareTo(myNode.nodeId)<0)||(keyId.compareTo(myNode.predecessor.nodeId)>0)))){

                                FileOutputStream outputStream;
                                Context context = getContext();
                                outputStream = context.openFileOutput(key, Context.MODE_PRIVATE);
                                outputStream.write(value.getBytes());
                                outputStream.close();
                                Log.v(TAG, "inserted: "+key+" "+value);
                                try{
                                    serverOut.writeUTF("insert request completed");

                                    socket1 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                        Integer.parseInt(requestorPort));
                                    DataOutputStream serverOut1 = new DataOutputStream(socket1.getOutputStream());
                                    DataInputStream serverIn1 = new DataInputStream(socket1.getInputStream());
                                    serverOut1.writeUTF("Key Inserted");

                                    String ack1=null;
                                    if ((ack1 = serverIn1.readUTF()).equals("insert ack")){
                                        serverIn1.close();
                                        serverOut1.close();
                                        socket1.close();}
                                }catch(Exception e){
                                }

                                serverOut.close();
                                outputSocket.close();

                            }else {

                                try{

                                    serverOut.writeUTF("insert request forwarded");

                                    socket2 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                        Integer.parseInt(myNode.successor.myPort));
                                    DataOutputStream serverOut2 = new DataOutputStream(socket2.getOutputStream());
                                    DataInputStream serverIn2 = new DataInputStream(socket2.getInputStream());

                                    serverOut2.writeUTF("3" + "!~!" + key + "!~!" + value + "!~!" + requestorPort);

                                    String ack1=null;
                                    if ((ack1 = serverIn2.readUTF()).equals("insert request forwarded")||(ack1 = serverIn2.readUTF()).equals("insert request completed")) {
                                        serverIn2.close();
                                        serverOut2.close();
                                        socket2.close();
                                        }
                                    }catch(Exception e){
                                }

                                serverOut.close();
                                outputSocket.close();

                            }
                        }

                        if(msgStrings[0].equals("Key Inserted")){

                            serverOut.writeUTF("insert ack");
                            serverOut.close();
                            outputSocket.close();

                        }

                        if(msgStrings[0].equals("4")){

                           Log.v(TAG,"message type 4-routed query request");

                            String key = msgStrings[1];
                            String value = null;
                            String requestorPort = msgStrings[2];
                            String keyId = genHash(key);

                            if(((keyId.compareTo(myNode.predecessor.nodeId)>0)&&(keyId.compareTo(myNode.nodeId))<=0)
                                    || ((myNode.nodeId.compareTo(myNode.predecessor.nodeId)<0)&&((keyId.compareTo(myNode.nodeId)<0)||(keyId.compareTo(myNode.predecessor.nodeId)>0)))){

                                FileInputStream inputStream;
                                Context context = getContext();
                                inputStream = context.openFileInput(key);
                                BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
                                if ((value = in.readLine()) != null) {
                                    Log.v(TAG,"found "+ key + " " + value);
                                }

                                inputStream.close();
                                try{
                                    serverOut.writeUTF("query request completed");
                                    socket1 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                        Integer.parseInt(requestorPort));
                                    DataOutputStream serverOut1 = new DataOutputStream(socket1.getOutputStream());
                                    DataInputStream serverIn1 = new DataInputStream(socket1.getInputStream());

                                    serverOut1.writeUTF("5" + "!~!"+key+ "!~!"+ value);
                                    String ack1=null;
                                    if ((ack1 = serverIn1.readUTF()).equals("query ack")){
                                        serverIn1.close();
                                        serverOut1.close();
                                        socket1.close();}
                                }catch(Exception e){
                                }

                                serverOut.close();
                                outputSocket.close();

                            }else {
                                try{
                                serverOut.writeUTF("query request forwarded");

                                 socket2 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                        Integer.parseInt(myNode.successor.myPort));
                                DataOutputStream serverOut2 = new DataOutputStream(socket2.getOutputStream());
                                DataInputStream serverIn2 = new DataInputStream(socket2.getInputStream());
                                serverOut2.writeUTF("4" + "!~!" + key + "!~!" + requestorPort);

                                String ack1=null;
                                if ((ack1 = serverIn2.readUTF()).equals("query request forwarded")||(ack1 = serverIn2.readUTF()).equals("query request completed")) {
                                    serverIn2.close();
                                    serverOut2.close();
                                    socket2.close();
                                }
                            }catch(Exception e){
                                }

                                serverOut.close();
                                outputSocket.close();
                            }

                        }

                        if(msgStrings[0].equals("5")) {

                            Log.v(TAG,"message type 5-response from routed query request");
                            String key = msgStrings[1];
                            String value = msgStrings[2];
                            String[] columnNames = new String[2];
                            columnNames[0] = "key";
                            columnNames[1] = "value";

                            mCursor = new MatrixCursor(columnNames);

                            if (value!= null) {
                                Log.v(TAG, "retrieved:key " +key+ "value "+ value);
                                Object[] columnValues = new Object[2];
                                columnValues[0] = key;
                                columnValues[1] = value;
                                mCursor.addRow(columnValues);
                            }

                            singleQueryCompleted=true;

                            serverOut.writeUTF("query ack");

                            serverOut.close();
                            outputSocket.close();

                        }

                        if(msgStrings[0].equals("6")) {

                            Log.v(TAG,"message type 6-routed query * request");
                            String requestorPort = msgStrings[1];
                            String keys = msgStrings[2];
                            String values = msgStrings[3];
                            //Log.v(TAG,"keys so far"+keys);
                            //Log.v(TAG,"values so far"+values);

                            if(!requestorPort.equals(myNode.successor.myPort)){
                                FileInputStream inputStream;
                                Context context = getContext();
                                String[] myList = context.fileList();

                                for(int i=0;i<myList.length;i++){
                                    Log.v(TAG,"context file "+myList[i]);
                                    inputStream = context.openFileInput(myList[i]);
                                    BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
                                    String currValue;
                                    if ((currValue = in.readLine()) != null) {
                                        Log.v(TAG, "retrieved "+ currValue);
                                        keys=keys+","+myList[i];
                                        values= values+","+currValue;
                                    }
                                }
                                try{
                                    serverOut.writeUTF("query request completed");
                                    socket1 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                        Integer.parseInt(myNode.successor.myPort));
                                    DataOutputStream serverOut1 = new DataOutputStream(socket1.getOutputStream());
                                    DataInputStream serverIn1 = new DataInputStream(socket1.getInputStream());

                                    serverOut1.writeUTF("6" + "!~!" + requestorPort + "!~!" + keys +"!~!" + values);
                                    String ack1=null;
                                    if ((ack1 = serverIn1.readUTF()).equals("query request completed")){
                                        serverIn1.close();
                                        serverOut1.close();
                                        socket1.close();}
                                }catch(Exception e){
                                }

                                serverOut.close();
                                outputSocket.close();

                            }else{

                                FileInputStream inputStream;
                                Context context = getContext();
                                String[] myList = context.fileList();

                                for(int i=0;i<myList.length;i++){
                                    Log.v(TAG,"context file "+myList[i]);
                                    inputStream = context.openFileInput(myList[i]);
                                    BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
                                    String currValue;
                                    if ((currValue = in.readLine()) != null) {
                                        Log.v(TAG, "retrieved "+ currValue);
                                        keys=keys+","+myList[i];
                                        values= values+","+currValue;
                                    }
                                }

                                try{
                                    serverOut.writeUTF("query request completed");
                                    socket2 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                        Integer.parseInt(requestorPort));
                                    DataOutputStream serverOut2 = new DataOutputStream(socket2.getOutputStream());
                                    DataInputStream serverIn2 = new DataInputStream(socket2.getInputStream());

                                    serverOut2.writeUTF("7" + "!~!"+keys+ "!~!"+ values);
                                    String ack1=null;
                                    if ((ack1 = serverIn2.readUTF()).equals("query request completed")) {
                                        serverIn2.close();
                                        serverOut2.close();
                                        socket2.close();
                                    }
                                }catch(Exception e){
                                }

                                serverOut.close();
                                outputSocket.close();
                            }

                        }

                        if(msgStrings[0].equals("7")){

                            Log.v(TAG,"message type 7-response from routed query * request");
                            String keysArr[] = msgStrings[1].split(",");
                            String valuesArr[] = msgStrings[2].split(",");

                            for(int i=1;i<keysArr.length;i++){

                                Log.v(TAG,keysArr[i]);
                                Log.v(TAG, valuesArr[i]);
                                Object[] columnValues = new Object[2];
                                columnValues[0] = keysArr[i];
                                columnValues[1] = valuesArr[i];
                                mCursor.addRow(columnValues);

                            }

                            queryCompleted=true;

                            serverOut.writeUTF("query request completed");
                            serverOut.close();
                            outputSocket.close();
                        }

                        if(msgStrings[0].equals("8")) {

                            Log.v(TAG,"message type 8-routed delete request");
                            String key = msgStrings[1];
                            String requestorPort = msgStrings[2];
                            boolean deleteFlag = false;
                            Context context = getContext();
                            String keyId = genHash(key);

                            if(((keyId.compareTo(myNode.predecessor.nodeId)>0)&&(keyId.compareTo(myNode.nodeId))<=0)
                                    || ((myNode.nodeId.compareTo(myNode.predecessor.nodeId)<0)&&((keyId.compareTo(myNode.nodeId)<0)||(keyId.compareTo(myNode.predecessor.nodeId)>0)))) {
                                try{

                                    deleteFlag = context.deleteFile(key);
                                    serverOut.writeUTF("delete request completed");
                                    socket1 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                        Integer.parseInt(requestorPort));
                                    DataOutputStream serverOut1 = new DataOutputStream(socket1.getOutputStream());
                                    DataInputStream serverIn1 = new DataInputStream(socket1.getInputStream());

                                    serverOut1.writeUTF("delete completed");
                                    String ack1=null;
                                    if ((ack1 = serverIn1.readUTF()).equals("delete ack")){
                                        serverIn1.close();
                                        serverOut1.close();
                                        socket1.close();}
                                }catch(Exception e){
                             }

                            serverOut.close();
                            outputSocket.close();

                        }else {
                            try{
                                serverOut.writeUTF("delete request forwarded");

                                socket2 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                        Integer.parseInt(myNode.successor.myPort));
                                DataOutputStream serverOut2 = new DataOutputStream(socket2.getOutputStream());
                                DataInputStream serverIn2 = new DataInputStream(socket2.getInputStream());
                                serverOut2.writeUTF("8" + "!~!" + key + "!~!" + requestorPort);

                                String ack1=null;
                                if ((ack1 = serverIn2.readUTF()).equals("delete request forwarded")||(ack1 = serverIn2.readUTF()).equals("delete request completed")) {
                                    serverIn2.close();
                                    serverOut2.close();
                                    socket2.close();
                                }
                            }catch(Exception e){
                            }

                            serverOut.close();
                            outputSocket.close();
                            }
                        }

                        if(msgStrings[0].equals("delete completed")){

                            Log.v(TAG,"message type 9-response from routed delete request");
                            serverOut.writeUTF("delete ack");

                            singleDeleteCompleted = true;
                            serverOut.close();
                            outputSocket.close();
                        }

                        if(msgStrings[0].equals("9")) {

                            Log.v(TAG,"message type 9-routed delete * request");
                            String requestorPort = msgStrings[1];
                            boolean deleteFlag = false;
                            Context context = getContext();

                            if (!requestorPort.equals(myNode.successor.myPort)) {

                                String[] myList = context.fileList();
                                for (int i = 0; i < myList.length; i++) {
                                    deleteFlag = context.deleteFile(myList[i]);
                                }

                                try{

                                serverOut.writeUTF("delete request completed");

                                socket1 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                        Integer.parseInt(myNode.successor.myPort));
                                DataOutputStream serverOut1 = new DataOutputStream(socket1.getOutputStream());
                                DataInputStream serverIn1 = new DataInputStream(socket1.getInputStream());

                                serverOut1.writeUTF("9" + "!~!" + requestorPort);
                                String ack1=null;
                                if ((ack1 = serverIn1.readUTF()).equals("delete request completed")){
                                    serverIn1.close();
                                    serverOut1.close();
                                    socket1.close();}
                            }catch(Exception e){
                            }

                                serverOut.close();
                                outputSocket.close();

                            } else{

                                String[] myList = context.fileList();
                                for (int i = 0; i < myList.length; i++) {
                                    deleteFlag = context.deleteFile(myList[i]);
                                }

                                try{
                                    serverOut.writeUTF("delete request completed");
                                    socket2 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                        Integer.parseInt(requestorPort));
                                    DataOutputStream serverOut2 = new DataOutputStream(socket2.getOutputStream());
                                    DataInputStream serverIn2 = new DataInputStream(socket2.getInputStream());
                                    serverOut2.writeUTF("Delete across DHT Complete");
                                    String ack1=null;
                                    if ((ack1 = serverIn2.readUTF()).equals("delete request completed")) {
                                        serverIn2.close();
                                        serverOut2.close();
                                        socket2.close();
                                    }
                                }catch(Exception e){
                                }
                                serverOut.close();
                                outputSocket.close();
                            }
                        }

                        if(msgStrings[0].equals("Delete across DHT Complete")){

                            Log.v(TAG,"message type 9-response from routed delete * request");
                            serverOut.writeUTF("delete request completed");

                            deleteCompleted=true;

                            serverOut.close();
                            outputSocket.close();
                        }
                    }
                } catch (IOException e) {
                    Log.e(TAG, "Error when listening to client ");
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }

            return null;
        }
    }

    private class ClientTask extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... msgs) {

            Log.v(TAG,"coming inside client"+msgs[0]);

            String myPort = msgs[0];
            String msgReceived = null;


            if(!(myPort.equals(OriginatorNode))) {

                try {

                    Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                            Integer.parseInt(OriginatorNode));

                    String msgType = "1";
                    String nodeId = genHash(nodeIdMap.get(myPort));

                    DataOutputStream clientOut = new DataOutputStream(socket.getOutputStream());
                    clientOut.writeUTF(msgType + "!~!" + nodeId + "!~!" + myPort);

                    DataInputStream clientIn = new DataInputStream(socket.getInputStream());

                    if ((msgReceived = clientIn.readUTF()).equals("Node Joined")) {

                        Log.d(TAG, "Ack received " + msgReceived);
                        clientIn.close();
                        clientOut.close();
                        socket.close();
                    }

                } catch (UnknownHostException e) {
                    Log.e(TAG, "ClientTask UnknownHostException");
                } catch (IOException e) {
                    Log.e(TAG, "ClientTask socket IOException");
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }
    }

}
