package edu.buffalo.cse.cse486586.groupmessenger2;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Queue;



/**
 * GroupMessengerActivity is the main Activity for the assignment.
 * 
 * @author stevko
 *
 */
public class GroupMessengerActivity extends Activity {

    static final String TAG = GroupMessengerActivity.class.getSimpleName();

    static final String[] clientPorts={"11108","11112","11116","11120","11124"};

    static final int SERVER_PORT = 10000;

    MyContext myContext;

    MessageProcessor messageProcessor=new MessageProcessor();

    int priority=0;

    int proposedMessageCounter=0;

    float agreedPriority=-1;

    float potentialPriority=-1;

    Comparator<Message> comparator=new priorityComparator();

    Queue<Message> pQueue=new PriorityQueue<Message>(10,comparator);

    Queue<Message> rearrangePQueue=new PriorityQueue<Message>(10,comparator);

    Queue<Float> helperQueue=new PriorityQueue<Float>();

    /*int messageCounter=0;

    int localMessageCounter=0;

    int totalMessageCounter=0;

    int processCompletionCounter=0;*/


    int avdCounter=5;

    int errAvd=-1;

    boolean isStarted=false;

    boolean isIdentifiedFault=false;

    Message prevProposedMessage=null;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_messenger);
        myContext=new MyContext(getContentResolver());

        /*
         * Calculate the port number that this AVD listens on.
         * It is just a hack that I came up with to get around the networking limitations of AVDs.
         * The explanation is provided in the PA1 spec.
         */
        TelephonyManager tel = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
        String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
        final String myPort = String.valueOf((Integer.parseInt(portStr) * 2));

        try {
            /*
             * Create a server socket as well as a thread (AsyncTask) that listens on the server
             * port.
             *
             * AsyncTask is a simplified thread construct that Android provides. Please make sure
             * you know how it works by reading
             * http://developer.android.com/reference/android/os/AsyncTask.html
             */
            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);

        } catch (IOException e) {
            /*
             * Log is a good way to debug your code. LogCat prints out all the messages that
             * Log class writes.
             *
             * Please read http://developer.android.com/tools/debugging/debugging-projects.html
             * and http://developer.android.com/tools/debugging/debugging-log.html
             * for more information on debugging.
             */
            Log.e(TAG, e.toString());
            Log.e(TAG, "Can't create a ServerSocket");
            return;
        }
        /*
         * TODO: Use the TextView to display your messages. Though there is no grading component
         * on how you display the messages, if you implement it, it'll make your debugging easier.
         */
        TextView tv = (TextView) findViewById(R.id.textView1);
        tv.setMovementMethod(new ScrollingMovementMethod());
        
        /*
         * Registers OnPTestClickListener for "button1" in the layout, which is the "PTest" button.
         * OnPTestClickListener demonstrates how to access a ContentProvider.
         */
        findViewById(R.id.button1).setOnClickListener(
                new OnPTestClickListener(tv, getContentResolver()));
        
        /*
         * TODO: You need to register and implement an OnClickListener for the "Send" button.
         * In your implementation you need to get the message from the input box (EditText)
         * and send it to other AVDs.
         */

        final EditText editText = (EditText) findViewById(R.id.editText1);



        final Button sendButton=(Button) findViewById(R.id.button4);

        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String msg = editText.getText().toString();
                editText.setText(""); // This is one way to reset the input box.
                TextView localTextView = (TextView) findViewById(R.id.textView1);
                localTextView.append("\t" + msg + "\n"); // This is one way to display a string.
                TextView remoteTextView = (TextView) findViewById(R.id.textView1);
                remoteTextView.append("\n");


                /*
                 * Note that the following AsyncTask uses AsyncTask.SERIAL_EXECUTOR, not
                 * AsyncTask.THREAD_POOL_EXECUTOR as the above ServerTask does. To understand
                 * the difference, please take a look at
                 * http://developer.android.com/reference/android/os/AsyncTask.html
                 */
                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, myPort);



            }
            }
        );
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_group_messenger, menu);
        return true;
    }

    private class ServerTask extends AsyncTask<ServerSocket, String, Void> {


        @Override
        protected Void doInBackground(ServerSocket... sockets) {
            ServerSocket serverSocket = sockets[0];
            String outputMsg = null;
            DataInputStream serverIn = null;
            DataOutputStream serverOut = null;
            Socket outputSocket = null;

            while (true) {
                try {
                    //Server socket listens for any connection made to this socket
                    outputSocket = serverSocket.accept();
                    outputSocket.setSoTimeout(500);
                    //read the message sent over the socket using DataInputStream object
                    serverIn = new DataInputStream(outputSocket.getInputStream());
                    outputMsg = serverIn.readUTF();


                    Message message = messageProcessor.process(outputMsg);

                    if (message.getType() == 2) {
                        //Acknowledge the message over the same socket by writing "PA-2 OK" using DataOutputStream object
                        serverOut = new DataOutputStream(outputSocket.getOutputStream());
                        serverOut.writeUTF(message.toString());
                        //totalMessageCounter++;
                    }

                    if (message.getType() == 3) {

                        Message msg = null;


                        //messageCounter++;

                        if (!isStarted) {
                            isStarted=true;
                            new Counter().start();
                        }

                        for (Message pMsg : pQueue) {
                            if(pMsg.isDeliverable()) {
                                rearrangePQueue.add(pMsg);
                            }
                        }

                        for(Message rPMsg:rearrangePQueue)
                        {
                            pQueue.remove(rPMsg);

                        }

                    }
                    //System.out.println("totalMessageCounter = " + totalMessageCounter + " messageCounter = " + messageCounter + " localMessageCounter = " + localMessageCounter + " processCompletionCounter = " + processCompletionCounter + " avdCounter = " + avdCounter + " errAvd = " + errAvd);

                } catch (SocketTimeoutException e) {
                    e.printStackTrace();
                    continue;
                } catch (SocketException e) {
                    e.printStackTrace();
                    continue;
                } catch (UnknownHostException e) {
                    Log.e(TAG, "ClientTask UnknownHostException");
                    e.printStackTrace();
                    continue;
                } catch (IOException e) {
                    Log.e(TAG, "ClientTask socket IOException");
                    e.printStackTrace();
                    continue;
                } catch (Exception e) {
                    e.printStackTrace();
                    continue;
                }
            }

        }


        protected void onProgressUpdate(String...strings) {
            /*
             * The following code displays what is received in doInBackground().
             */
            String strReceived = strings[0].trim();
            TextView remoteTextView = (TextView) findViewById(R.id.textView1);
            remoteTextView.append(strReceived + "\t\n");
            TextView localTextView = (TextView) findViewById(R.id.textView1);
            localTextView.append("\n");

            /*
             * The following code creates a file in the AVD's internal storage and stores a file.
             *
             * For more information on file I/O on Android, please take a look at
             * http://developer.android.com/training/basics/data-storage/files.html
             */

            String filename = "GroupMessengerOutput";
            String string = strReceived + "\n";
            FileOutputStream outputStream;

            try {
                outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
                outputStream.write(string.getBytes());
                outputStream.close();
            } catch (Exception e) {
                Log.e(TAG, "File write failed");
            }

            return;
        }
    }

    /***
     * ClientTask is an AsyncTask that should send a string over the network.
     * It is created by ClientTask.executeOnExecutor() call whenever OnKeyListener.onKey() detects
     * an enter key press event.
     *
     * @author stevko
     *
     */
    private class ClientTask extends AsyncTask<String, Void, Void> {

        Socket socket=null, socket1=null;
        DataOutputStream clientOut=null;
        DataInputStream clientIn=null;


        @Override
        protected Void doInBackground(String... msgs) {

            int currAvd = 0;

            for (int i = 0; i < 5; i++) {

                try {

                    currAvd = i;
                    if (currAvd == errAvd && !isIdentifiedFault) {
                        isIdentifiedFault = true;
                        avdCounter--;
                    }

                    socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                            Integer.parseInt(clientPorts[i]));

                    socket.setSoTimeout(500);

                    String msgToSend = msgs[0];

                    Message message = new Message(((Integer.parseInt(msgs[1]) - 11104) / 4));

                    message.setValue(msgToSend);

                    String value=null;

                    Message processedMessage=null;

                    try {
                        //send the message over socket using DataOutputStream object
                        clientOut = new DataOutputStream(socket.getOutputStream());

                        clientOut.writeUTF(message.toString());

                        clientIn = new DataInputStream(socket.getInputStream());

                        value= clientIn.readUTF();

                    }catch(Exception e){
                        //e.printStackTrace();
                        Log.e(TAG,"Client Socket Closed");
                    }finally {

                        if(value==null)
                            processedMessage = messageProcessor.process(value,2);
                        else
                            processedMessage = messageProcessor.process(value);
                    }

                    //localMessageCounter++;

                    if (processedMessage.getType() == 3) {

                        proposedMessageCounter = 0;

                        prevProposedMessage=null;

                        for (int j = 0; j < 5; j++) {

                            try {
                                currAvd = j;


                                socket1 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                        Integer.parseInt(clientPorts[j]));
                                socket1.setSoTimeout(500);

                                //send the message over socket using DataOutputStream object
                                DataOutputStream clientOut = new DataOutputStream(socket1.getOutputStream());

                                clientOut.writeUTF(processedMessage.toString());

                            } catch(SocketTimeoutException e){
                                errAvd = currAvd;
                                e.printStackTrace();
                                continue;
                            }catch(SocketException e){
                                errAvd = currAvd;
                                e.printStackTrace();
                                continue;
                            }catch(UnknownHostException e){
                                errAvd = currAvd;
                                Log.e(TAG, "ClientTask UnknownHostException");
                                e.printStackTrace();
                                continue;
                            }catch(IOException e){
                                errAvd = currAvd;
                                Log.e(TAG, "ClientTask socket IOException");
                                e.printStackTrace();
                                continue;
                            }catch(Exception e){
                                errAvd = currAvd;
                                e.printStackTrace();
                                continue;
                            }
                            finally{
                                try {
                                    if (clientOut != null)
                                        clientOut.close();
                                }catch(Exception e){
                                    e.printStackTrace();
                                }
                            }
                        }
                    }
                } catch(SocketTimeoutException e){
                errAvd = currAvd;
                e.printStackTrace();
                continue;
            }catch(SocketException e){
                errAvd = currAvd;
                e.printStackTrace();
                    continue;
            }catch(UnknownHostException e){
                errAvd = currAvd;
                Log.e(TAG, "ClientTask UnknownHostException");
                    e.printStackTrace();
                    continue;
            }catch(IOException e){
                errAvd = currAvd;
                Log.e(TAG, "ClientTask socket IOException");
                e.printStackTrace();
                    continue;
            }catch(Exception e){
                errAvd = currAvd;
                e.printStackTrace();
                    continue;
            }
            finally{
                    try {
                        if (clientIn != null)
                            clientIn.close();
                        if (clientOut != null)
                            clientOut.close();
                    }catch(Exception e){
                        e.printStackTrace();
                    }
            }
        }
            return null;
        }
    }

    private class priorityComparator implements Comparator<Message>
    {
        public int compare(Message x, Message y)
        {
            float result=x.getPriority()-y.getPriority();

            if(result>0)
                return 1;
            else if(result<0)
                return -1;
            else
                return 0;

        }
    }

    public class Counter extends Thread {

        int lastTotalCount=0;

        public boolean reArrange(){


            if (rearrangePQueue.size()==0)
                return true;

            if(lastTotalCount!=rearrangePQueue.size()) {

                lastTotalCount=rearrangePQueue.size();

                return true;

            }else {

                return false;
            }
        }

        public void run() {

            while(true){

                try {
                    if(reArrange())
                        Thread.sleep(3000);
                    else{
                        Message msg1 = null;
                    while ((msg1 = rearrangePQueue.poll()) != null) {
                        if (msg1.isDeliverable()) {
                            //System.out.println(msg1.toString());
                             //publishProgress(msg1.getValue());
                            myContext.add(msg1.getValue());
                        }    }

                } }catch (InterruptedException e) {
                    e.printStackTrace();
                    continue;
                }
            }
        }
    }

    private class MessageProcessor{

        Message process(String messageString){

            String[] messageStrings = messageString.split("!~!");
            Message message = new Message(messageStrings[0], messageStrings[1], messageStrings[2], messageStrings[3], messageStrings[4]);

            if(message.getType()==1) {

                if(agreedPriority>priority)
                    priority=(int)agreedPriority;

                message.setPriority((float) (++priority + 0.1 * message.getProcessID()));

                message.setType(2);


            }else if(message.getType()==2){

                prevProposedMessage=message;

                if(potentialPriority<message.priority){

                    potentialPriority=message.priority;
                }

                proposedMessageCounter++;

                if(proposedMessageCounter==5){
                    agreedPriority=potentialPriority;
                    message.setType(3);
                    message.setPriority(agreedPriority);

                }

            }else if(message.getType()==3){

                        message.setDeliverable(true);

                        pQueue.add(message);

                }

            return message;
        }

        Message process(String messageString, int type) {

            Message message=null;

            if(type==2) {

                if(prevProposedMessage!=null)
                    message=prevProposedMessage;
                else
                    message=new Message(100);


                proposedMessageCounter++;

                if (proposedMessageCounter == 5) {
                    agreedPriority = potentialPriority;
                    message.setType(3);
                    message.setPriority(agreedPriority);

                }
            }

        return message;

        }
    }
}
