package edu.buffalo.cse.cse486586.groupmessenger2;

import java.io.Serializable;

/**
 * Created by nishanthi on 4/1/17.
 */

public class Message{

    float priority;
    String value;
    int type;
    int processID;
    boolean isDeliverable;

    public Message(int pID){

        priority=0.0f;
        value="";
        type=1;
        processID=pID;
        isDeliverable=false;
    }

    public Message(String priority, String value, String type, String processID, String isDeliverable){

        this.priority=Float.parseFloat(priority);
        this.value=value;
        this.type=Integer.parseInt(type);
        this.processID=Integer.parseInt(processID);
        this.isDeliverable=Boolean.parseBoolean(isDeliverable);
    }

    @Override
    public String toString() {
        return priority+"!~!"+value+"!~!"+type+"!~!"+processID+"!~!"+isDeliverable;
    }

    public float getPriority() {
        return priority;
    }

    public void setPriority(float priority) {
        this.priority = priority;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getProcessID() {
        return processID;
    }

    public void setProcessID(int processID) {
        this.processID = processID;
    }

    public boolean isDeliverable() {
        return isDeliverable;
    }

    public void setDeliverable(boolean deliverable) {
        isDeliverable = deliverable;
    }




}
