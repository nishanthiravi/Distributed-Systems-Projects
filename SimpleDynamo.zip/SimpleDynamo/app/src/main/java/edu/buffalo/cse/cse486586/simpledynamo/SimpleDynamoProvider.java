package edu.buffalo.cse.cse486586.simpledynamo;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Formatter;
import java.util.HashMap;
import java.util.List;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.util.Log;

import static android.content.ContentValues.TAG;

public class SimpleDynamoProvider extends ContentProvider {

	static final int SERVER_PORT = 10000;

	static HashMap<String,String> nodeIdMap = new HashMap<String,String>();

	static HashMap<String,String> portHashIDMap = new HashMap<String,String>();

	static List<String[]> PartitionList  = new ArrayList<String[]>();

	String identifiedPort=null;

	MatrixCursor mCursor = null;

	//to test if the avd has recovered
	Thread thread = new Thread(new Runnable() {

		@Override
		public void run() {
			try  {
				if(test(identifiedPort)){
					recoverValues(identifiedPort);
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	});

	//to set the port number for emulators
	private void setNodeIdForEmulators() {

		nodeIdMap.put("11108","5554");
		nodeIdMap.put("11112","5556");
		nodeIdMap.put("11116","5558");
		nodeIdMap.put("11120","5560");
		nodeIdMap.put("11124","5562");
	}

	//to form the ring
	private void generatePartitionList() {

		for(String port: nodeIdMap.keySet()){
			try {
				String hashId = genHash(nodeIdMap.get(port));
				String[] node = new String[2];
				node[0] = hashId;
				node[1] = port;
				PartitionList.add(node);
				portHashIDMap.put(port,hashId);
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			}
		}
	}

	//to get the predecessor node in case of recovery
	private String getPrevNode(String currentPort){

		int index=-1;
		String prevNode=null;

		for(String[] node:PartitionList) {
			index++;
			if (node[1].equals(currentPort)) {
				if (index - 1 < 0) {
					prevNode = PartitionList.get((index-1) + PartitionList.size())[1];
				} else {
					prevNode = PartitionList.get(index - 1)[1];
				}
				break;
			}
		}
		return prevNode;
	}

	//to get the successor node in case of recovery
	private String getNextNode(String currentPort){

		int index=-1;
		String nextNode=null;

		for(String[] node:PartitionList) {
			index++;
			if (node[1].equals(currentPort)) {
				if (index + 1 > PartitionList.size() - 1) {
					nextNode = PartitionList.get((index + 1) % PartitionList.size())[1];
				} else {
					nextNode = PartitionList.get((index + 1))[1];
				}
				break;
			}
		}
		return nextNode;
	}

	//to get the key belonging to my node after recovery
	private String getNodeKeyValue(String port, String keyValues){

		String[] keys=keyValues.split("!~!")[0].split(",");
		String[] values=keyValues.split("!~!")[1].split(",");
		String nodeKeys=null,nodeValues=null;
		String nodeKeyValue=null;

		try {
			String currentNodeHashId = genHash(nodeIdMap.get(port));
			String prevNodeHashId =  genHash(nodeIdMap.get(getPrevNode(port)));

			for (int i=0;i<keys.length;i++) {
				String keyId = genHash(keys[i]);
				if (((keyId.compareTo(prevNodeHashId) > 0) && (keyId.compareTo(currentNodeHashId) <= 0))||((currentNodeHashId.compareTo(prevNodeHashId)<0)&&((keyId.compareTo(prevNodeHashId) > 0) || (keyId.compareTo(currentNodeHashId) <= 0)))){
					if(nodeKeys!=null) {
						nodeKeys = nodeKeys + "," + keys[i];
						nodeValues = nodeValues + "," + values[i];
					}else{
						nodeKeys = keys[i];
						nodeValues = values[i];
					}
				}
			}
			nodeKeyValue=nodeKeys+"!~!"+nodeValues;
		}catch(Exception e){
			Log.v(TAG," Error in Node key value method");
			//e.printStackTrace();
		}

		return nodeKeyValue;
	}

	//insert the recovered keys into my context
	private synchronized void insertAfterRecovery(String port, String key, String value){

		try {
			Log.v(TAG,"insert after recovery routed to "+port);
			Socket contentProviderSocket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
					Integer.parseInt(port));
			DataOutputStream contentProviderStream = new DataOutputStream(contentProviderSocket.getOutputStream());
			DataInputStream contentProviderInputStream = new DataInputStream(contentProviderSocket.getInputStream());
			contentProviderStream.writeUTF("6" + "!~!" + key + "!~!" + value + "!~!" + port);
			if (contentProviderInputStream.readUTF().equals("Key Inserted")) {
				contentProviderInputStream.close();
				contentProviderStream.close();
				contentProviderSocket.close();
			}
		}catch(Exception e){
			//e.printStackTrace();
		}
	}

	//to test if the avd has recovered
	private boolean test(String port){

		try {
			Log.v(TAG,"test routed to "+port);
			Socket contentProviderSocket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
					Integer.parseInt(port));
			DataOutputStream contentProviderStream = new DataOutputStream(contentProviderSocket.getOutputStream());
			DataInputStream contentProviderInputStream = new DataInputStream(contentProviderSocket.getInputStream());
			contentProviderStream.writeUTF("Test" + "!~!"+ port);
			if (contentProviderInputStream.readUTF().equals("Test Success")) {
				contentProviderInputStream.close();
				contentProviderStream.close();
				contentProviderSocket.close();
				return true;
			}
		}catch(Exception e){
			test(identifiedPort);
			//e.printStackTrace();
		}
		return false;
	}

	private synchronized void recoverValues(String currentPort){

		int index=-1;
		String[] neighbours=new String[3];

		neighbours[0]=getPrevNode(currentPort);
		neighbours[1]=getPrevNode(getPrevNode(currentPort));
		neighbours[2]=getNextNode(currentPort);

		String keys = null;
		String values = null;
		HashMap<String,String> versionMap = new HashMap<String,String>();
		Socket contentProviderSocket = null;
		DataOutputStream contentProviderStream = null;
		DataInputStream contentProviderInputStream = null;

			for(int i=0;i<neighbours.length;i++){

					String port = neighbours[i];
				try {
					contentProviderSocket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
							Integer.parseInt(port));
					contentProviderStream = new DataOutputStream(contentProviderSocket.getOutputStream());
					contentProviderInputStream = new DataInputStream(contentProviderSocket.getInputStream());
					contentProviderStream.writeUTF("3" + "!~!" + port);
					String msgReceived = null;
					if (((msgReceived = contentProviderInputStream.readUTF())!=null)&& !msgReceived.split("!~!")[0].equals("null")) {

						//to retrieve only its corresponding key and values
						if(i==2){
							//to get the failure node's data from successor node.
							msgReceived=getNodeKeyValue(currentPort,msgReceived);

						}else{

							msgReceived=getNodeKeyValue(port,msgReceived);
						}

						String[] msgStrings = msgReceived.split("!~!");
						if(!(msgStrings[0].equals("null")||msgStrings[0]==null)) {
							if (keys == null && values == null) {
								keys = msgStrings[0];
								values = msgStrings[1];
							} else {
								keys = keys + "," + msgStrings[0];
								values = values + "," + msgStrings[1];
							}
						}
					}
				}catch(Exception e){
					//e.printStackTrace();
					//continue;
				}
					if(i == 2 && keys!=null) {
						Log.v(TAG, "final keys list "+keys);
						Log.v(TAG, "final values list "+values);
						String keysArr[] = keys.split(",");
						String valuesArr[] = values.split(",");

						for(int k=0;k<keysArr.length;k++) {

							String currValuesArr[] = valuesArr[k].split("@");
							int currVersion = Integer.parseInt(currValuesArr[0]);
							if(versionMap.containsKey(keysArr[k])){
								String existingValue = versionMap.get(keysArr[k]);
								String existingValueArr[] = existingValue.split("@");
								int existingVersion = Integer.parseInt(existingValueArr[0]);
								if(currVersion>existingVersion){
									versionMap.put(keysArr[k],valuesArr[k]);
								}
							} else{
								versionMap.put(keysArr[k],valuesArr[k]);
							}
						}

						for(String key:versionMap.keySet()){
							String value = versionMap.get(key);
							insertAfterRecovery(currentPort, key, value);
						}
						try {
							if (contentProviderInputStream != null) {
								contentProviderInputStream.close();
								contentProviderStream.close();
								contentProviderSocket.close();
							}
						}catch (Exception e){
							//e.printStackTrace();
						}

					}
			}

		}


	@Override
	public boolean onCreate() {

		Context context = getContext();
		TelephonyManager tel = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
		String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
		final String myPort = String.valueOf((Integer.parseInt(portStr) * 2));
		identifiedPort=myPort;
		Log.v(TAG, "my port" + myPort);
		setNodeIdForEmulators();
		generatePartitionList();
		//sort the partitiionList
		Collections.sort(PartitionList, new Comparator<String[]>() {
			@Override
			public int compare(String[] lhs, String[] rhs) {
				return lhs[0].compareTo(rhs[0]);
			}
		});

		for (String[] p : PartitionList) {
			Log.v(TAG, p[0]+" "+p[1]);
		}

		try{
			ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
			AsyncTask<ServerSocket, String, Void> serverTask=new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);

			thread.start();
		}catch (IOException e) {
			Log.e(TAG, e.toString());
			Log.e(TAG, "Can't create a ServerSocket");
		}
		return true;
	}

	@Override
	public synchronized Uri insert(Uri uri, ContentValues values) {

		String key = values.getAsString("key");
		String value = values.getAsString("value");
		try {
			String keyId = genHash(key);
			boolean inserted = false;
			Log.v(TAG, "insert request " + key + " hash code " + keyId);
			FileOutputStream outputStream;
			Context context = getContext();
			int plstLength = PartitionList.size();
			int ackLength = 0;

			for(int i=1;i<plstLength;i++){
				String[] prevNode = PartitionList.get(i-1);
				String[] currNode = PartitionList.get(i);
				if((keyId.compareTo(prevNode[0])>0) && (keyId.compareTo(currNode[0])<=0)){
					for(int j=0;j<=2;j++){
						try {
							String port = PartitionList.get((i+j)%plstLength)[1];
							Socket contentProviderSocket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
									Integer.parseInt(port));
							DataOutputStream contentProviderStream = new DataOutputStream(contentProviderSocket.getOutputStream());
							DataInputStream contentProviderInputStream = new DataInputStream(contentProviderSocket.getInputStream());
							contentProviderStream.writeUTF("1" + "!~!" + key + "!~!" + value + "!~!" + port);
							if (contentProviderInputStream.readUTF().equals("Key Inserted")) {
								Log.v(TAG,"Key Inserted");
								ackLength++;
							}
							if(ackLength == 3){
								contentProviderInputStream.close();
								contentProviderStream.close();
								contentProviderSocket.close();
							}
						}catch(Exception e){
							//e.printStackTrace();
						}
					}
					inserted = true;
				}
				if(inserted)
					break;
			}
			if(!inserted){
				for(int j=0;j<=2;j++) {
					try {
						String port = PartitionList.get(j)[1];
						Socket contentProviderSocket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
								Integer.parseInt(port));
						DataOutputStream contentProviderStream = new DataOutputStream(contentProviderSocket.getOutputStream());
						DataInputStream contentProviderInputStream = new DataInputStream(contentProviderSocket.getInputStream());
						contentProviderStream.writeUTF("1" + "!~!" + key + "!~!" + value + "!~!" + port);
						if (contentProviderInputStream.readUTF().equals("Key Inserted")) {
							Log.v(TAG,"Key Inserted");
							ackLength++;
						}
						if(ackLength == 3){
							contentProviderInputStream.close();
							contentProviderStream.close();
							contentProviderSocket.close();
						}
					} catch (Exception e) {
						//e.printStackTrace();
					}
				}
			}
		}catch (Exception e) {
			Log.e(TAG, "File write failed");
		}
		return uri;
	}

	@Override
	public synchronized Cursor query(Uri uri, String[] projection, String selection,
						String[] selectionArgs, String sortOrder) {

		boolean queried = false;

		try {

			Log.v(TAG,"query request "+selection);
			FileInputStream inputStream;
			Context context = getContext();
			int plstLength = PartitionList.size();

			if(selection.equals("@")){
				String[] myList = context.fileList();
				String[] columnNames = new String[2];
				columnNames[0] = "key";
				columnNames[1] = "value";

				mCursor = new MatrixCursor(columnNames);

				for(int i=0;i<myList.length;i++){
					Log.v(TAG,"context file "+myList[i]);
					inputStream = context.openFileInput(myList[i]);
					BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
					String receivedValue;
					if ((receivedValue = in.readLine()) != null) {
						Log.v(TAG, "retrieved "+ receivedValue);
						String valuesArr[] = receivedValue.split("@");
						Object[] columnValues = new Object[2];
						columnValues[0] = myList[i];
						columnValues[1] = valuesArr[1];
						mCursor.addRow(columnValues);
					}
				}

				return mCursor;

				} else if(selection.equals("*")) {

				String[] myList = context.fileList();
				String[] columnNames = new String[2];
				columnNames[0] = "key";
				columnNames[1] = "value";
				String keys = null;
				String values = null;
				int ackLength = 0;
				HashMap<String,String> versionMap = new HashMap<String,String>();

				mCursor = new MatrixCursor(columnNames);


				for(int i=0;i<plstLength;i++){

					Socket contentProviderSocket = null;
					DataOutputStream contentProviderStream = null;
					DataInputStream contentProviderInputStream = null;

					try {
						String port = PartitionList.get(i)[1];
						contentProviderSocket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
								Integer.parseInt(port));
						contentProviderStream = new DataOutputStream(contentProviderSocket.getOutputStream());
						contentProviderInputStream = new DataInputStream(contentProviderSocket.getInputStream());
						contentProviderStream.writeUTF("3" + "!~!" + port);
						String msgReceived = null;
						if ((msgReceived = contentProviderInputStream.readUTF())!=null) {
								String[] msgStrings = msgReceived.split("!~!");
							if(keys==null&&values==null){
								keys = msgStrings[0];
								values = msgStrings[1];
							}else {
								keys = keys + "," + msgStrings[0];
								values = values + "," + msgStrings[1];
							}

							ackLength++;
						}
					}catch(Exception e){
					}
						if(i == plstLength-1) {
							Log.v(TAG, "final keys list "+keys);
							Log.v(TAG, "final values list "+values);
							String keysArr[] = keys.split(",");
							String valuesArr[] = values.split(",");

							for(int k=0;k<keysArr.length;k++) {

								String currValuesArr[] = valuesArr[k].split("@");
								int currVersion = Integer.parseInt(currValuesArr[0]);
								if(versionMap.containsKey(keysArr[k])){
									String existingValue = versionMap.get(keysArr[k]);
									String existingValueArr[] = existingValue.split("@");
									int existingVersion = Integer.parseInt(existingValueArr[0]);
									if(currVersion>existingVersion){
										versionMap.put(keysArr[k],valuesArr[k]);
									}
								} else{
									versionMap.put(keysArr[k],valuesArr[k]);
								}
							}

							for(String key:versionMap.keySet()){
								String valueArray[] = versionMap.get(key).split("@");
								String value = valueArray[1];
								Object[] columnValues = new Object[2];
								columnValues[0] = key;
								columnValues[1] = value;
								mCursor.addRow(columnValues);
							}
							if(contentProviderInputStream!=null) {
								contentProviderInputStream.close();
								contentProviderStream.close();
								contentProviderSocket.close();
							}
						}
				}

				return mCursor;
			}

			//Single query request
			String keyId = genHash(selection);
			String value = null;
			int ackLength = 0;
			int version =0;
			String receivedValue = null;

			for(int i=1;i<plstLength;i++){
				String[] prevNode = PartitionList.get(i-1);
				String[] currNode = PartitionList.get(i);
				if((keyId.compareTo(prevNode[0])>0) && (keyId.compareTo(currNode[0])<=0)){
					for(int j=0;j<=2;j++){
						Socket contentProviderSocket = null;
						DataOutputStream contentProviderStream = null;
						DataInputStream contentProviderInputStream = null;
						try {
							String port = PartitionList.get((i+j)%plstLength)[1];
							contentProviderSocket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
									Integer.parseInt(port));
							contentProviderStream = new DataOutputStream(contentProviderSocket.getOutputStream());
							contentProviderInputStream = new DataInputStream(contentProviderSocket.getInputStream());
							contentProviderStream.writeUTF("2" + "!~!" + selection + "!~!" + port);
							if ((receivedValue = contentProviderInputStream.readUTF())!=null) {
								Log.v(TAG,"value received "+receivedValue);
								String valuesArr[] = receivedValue.split("@");
								int currVersion = Integer.parseInt(valuesArr[0]);
								String currValue = valuesArr[1];
								if(version<currVersion){
									version = currVersion;
									value = currValue;
								}
								ackLength++;
							}
						}catch(Exception e){
							ackLength++;
							//e.printStackTrace();
						}
							if(j == 2){
								String[] columnNames = new String[2];
								columnNames[0] = "key";
								columnNames[1] = "value";
								mCursor = new MatrixCursor(columnNames);
								Object[] columnValues = new Object[2];
								columnValues[0] = selection;
								columnValues[1] = value;
								mCursor.addRow(columnValues);
								if(contentProviderInputStream!=null) {
									contentProviderInputStream.close();
									contentProviderStream.close();
									contentProviderSocket.close();
								}
							}

					}
					queried = true;
				}
				if(queried)
					break;
			}
			if(!queried) {
				for (int j= 0; j <= 2; j++) {

					Socket contentProviderSocket = null;
					DataOutputStream contentProviderStream = null;
					DataInputStream contentProviderInputStream = null;
					try {
						String port = PartitionList.get(j)[1];
						contentProviderSocket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
								Integer.parseInt(port));
						contentProviderStream = new DataOutputStream(contentProviderSocket.getOutputStream());
						contentProviderInputStream = new DataInputStream(contentProviderSocket.getInputStream());
						contentProviderStream.writeUTF("2" + "!~!" + selection+ "!~!" + port);
						if ((receivedValue = contentProviderInputStream.readUTF())!=null) {
							Log.v(TAG,"value received "+receivedValue);
							String valuesArr[] = receivedValue.split("@");
							int currVersion = Integer.parseInt(valuesArr[0]);
							String currValue = valuesArr[1];
							if(version<currVersion){
								version = currVersion;
								value = currValue;
							}
							ackLength++;
						}
					} catch (Exception e) {
						//e.printStackTrace();
					}
						if(j == 2){
							String[] columnNames = new String[2];
							columnNames[0] = "key";
							columnNames[1] = "value";
							mCursor = new MatrixCursor(columnNames);
							Object[] columnValues = new Object[2];
							columnValues[0] = selection;
							columnValues[1] = value;
							mCursor.addRow(columnValues);
							if(contentProviderInputStream!=null) {
								contentProviderInputStream.close();
								contentProviderStream.close();
								contentProviderSocket.close();
							}
						}
				}
			}

			}catch (Exception e) {
				Log.e(TAG, "Error when reading from file");
			}

			return mCursor;
	}

	@Override
	public synchronized int delete(Uri uri, String selection, String[] selectionArgs) {
		Context context = getContext();
		boolean deleteFlag = false;
		int plstLength = PartitionList.size();

		try {
			//delete @ request
			if (selection.equals("@")){
				String[] myList = context.fileList();
				for (int i = 0; i < myList.length; i++) {
					deleteFlag = context.deleteFile(myList[i]);
				}
			}
			//delete * request
			else if (selection.equals("*")) {

				int ackLength = 0;
				for(int i=0;i<plstLength;i++){
					try {
						String port = PartitionList.get(i)[1];
						Socket contentProviderSocket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
								Integer.parseInt(port));
						DataOutputStream contentProviderStream = new DataOutputStream(contentProviderSocket.getOutputStream());
						DataInputStream contentProviderInputStream = new DataInputStream(contentProviderSocket.getInputStream());
						contentProviderStream.writeUTF("5" + "!~!" + port);
						if (contentProviderInputStream.readUTF().equals("Key Deleted")) {
							Log.v(TAG,"Key Deleted");
							ackLength++;
						}
						if (i == 4) {
							contentProviderInputStream.close();
							contentProviderStream.close();
							contentProviderSocket.close();
						}
					}catch(Exception e){
					}
				}
			}

			//single delete request
			String keyId = genHash(selection);
			int ackLength = 0;

			for(int i=1;i<plstLength;i++){
				String[] prevNode = PartitionList.get(i-1);
				String[] currNode = PartitionList.get(i);
				if((keyId.compareTo(prevNode[0])>0) && (keyId.compareTo(currNode[0])<=0)){
					for(int j=0;j<=2;j++){
						try {
							String port = PartitionList.get((i+j)%plstLength)[1];
							Socket contentProviderSocket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
									Integer.parseInt(port));
							DataOutputStream contentProviderStream = new DataOutputStream(contentProviderSocket.getOutputStream());
							DataInputStream contentProviderInputStream = new DataInputStream(contentProviderSocket.getInputStream());
							contentProviderStream.writeUTF("4" + "!~!" + selection + "!~!" + port);
							if (contentProviderInputStream.readUTF().equals("Key Deleted")) {
								Log.v(TAG,"Key Deleted");
								ackLength++;
							}
							if(j == 2){
								contentProviderInputStream.close();
								contentProviderStream.close();
								contentProviderSocket.close();
							}
						}catch(Exception e){
							//e.printStackTrace();
						}
					}
					deleteFlag = true;
				}
				if(deleteFlag)
					break;
			}

			if(!deleteFlag) {
				for (int j= 0; j <= 2; j++) {
					try {
						String port = PartitionList.get(j)[1];
						Socket contentProviderSocket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
								Integer.parseInt(port));
						DataOutputStream contentProviderStream = new DataOutputStream(contentProviderSocket.getOutputStream());
						DataInputStream contentProviderInputStream = new DataInputStream(contentProviderSocket.getInputStream());
						contentProviderStream.writeUTF("4" + "!~!" + selection+ "!~!" + port);
						if (contentProviderInputStream.readUTF().equals("Key Deleted")) {
							ackLength++;
						}
						if(ackLength == 3){
							Log.v(TAG,"Key Deleted");
							contentProviderInputStream.close();
							contentProviderStream.close();
							contentProviderSocket.close();
						}
					} catch (Exception e) {
						//e.printStackTrace();
					}
				}
			}
		} catch(Exception e){
			Log.e(TAG, "Error when deleting file");
		}
		if(deleteFlag)
			return 1;
		else
			return 0;
	}

	private class ServerTask extends AsyncTask<ServerSocket, String, Void> {

		@Override
		protected Void doInBackground(ServerSocket... sockets) {
			ServerSocket serverSocket = sockets[0];
			String msgReceived = null;
			String msgStrings[] = null;


				while (true) {
					try {

					Socket socket1 = null;
					Socket socket2 = null;
					//Server socket listens for any connection made to this socket
					Socket outputSocket = serverSocket.accept();
					//read the message sent over the socket using DataInputStream object
					DataInputStream serverIn = new DataInputStream(outputSocket.getInputStream());

					DataOutputStream serverOut = new DataOutputStream(outputSocket.getOutputStream());


					if ((msgReceived = serverIn.readUTF()) != null) {

						Log.v(TAG, "message received " + msgReceived);
						msgStrings = msgReceived.split("!~!");
					}
					if(msgStrings[0].equals("Test")){

						Log.v(TAG, "message type Test");
						try{
							serverOut.writeUTF("Test Success");

						}catch(Exception e){
						}

						serverOut.close();
						outputSocket.close();

					}
					if(msgStrings[0].equals("1")) {

						Log.v(TAG, "message type 1-insert request");

						String key = msgStrings[1];
						String value = msgStrings[2];
						String requestorPort = msgStrings[3];
						int version =0;
						FileOutputStream outputStream;
						Context context = getContext();
						File file = context.getFileStreamPath(key);
						if(file.exists()){
							FileInputStream inputStream;
							inputStream = context.openFileInput(key);
							BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
							String existingValue = null;
							if ((existingValue = in.readLine()) != null) {
								String[] valueArr = existingValue.split("@");
								String currVersion = valueArr[0];
								String currValue = valueArr[1];

								if(!value.contains("@"))
									value = (Integer.parseInt(currVersion)+1)+"@"+value;
								else
									value = (Integer.parseInt(currVersion)+1)+"@"+value.split("@")[1];

							}
							outputStream = context.openFileOutput(key, Context.MODE_PRIVATE);
							outputStream.write(value.getBytes());
							inputStream.close();
						}else {

							if(!value.contains("@")){

								value = (++version) + "@" + value;
							}else{
								value = (++version) + "@" + value.split("@")[1];
							}
							outputStream = context.openFileOutput(key, Context.MODE_PRIVATE);
							outputStream.write(value.getBytes());
						}
						outputStream.close();
						Log.v(TAG, "inserted: "+key+" "+value);
						try{
							 serverOut.writeUTF("Key Inserted");

						}catch(Exception e){
						}

						serverOut.close();
						outputSocket.close();
					}
					if(msgStrings[0].equals("2")) {

						Log.v(TAG, "message type 2-query request");

						String key = msgStrings[1];
						String value = null;
						String requestorPort = msgStrings[2];
						FileInputStream inputStream;
						Context context = getContext();
						inputStream = context.openFileInput(key);
						BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
						if ((value = in.readLine()) != null) {
							Log.v(TAG,"found "+ key + " " + value);
						}
						inputStream.close();
						serverOut.writeUTF(value);
						serverOut.close();
						outputSocket.close();
					}
					if(msgStrings[0].equals("3")) {

						Log.v(TAG, "message type 3-query * request");

						String requestorPort = msgStrings[1];
						String keys = null;
						String values = null;
						Log.v(TAG,"keys so far"+keys);
						Log.v(TAG,"values so far"+values);
						FileInputStream inputStream = null;
						Context context = getContext();
						String[] myList = context.fileList();

						for(int i=0;i<myList.length;i++){
							Log.v(TAG,"context file "+myList[i]);
							inputStream = context.openFileInput(myList[i]);
							BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
							String currValue;
							if ((currValue = in.readLine()) != null) {
								Log.v(TAG, "retrieved "+ currValue);
								if(keys==null && values==null){
									keys = myList[i];
									values = currValue;
								}else {
									keys = keys + "," + myList[i];
									values = values + "," + currValue;
								}
							}
						}
							serverOut.writeUTF(keys+"!~!"+values);

						if(inputStream!=null) {
							inputStream.close();
							serverOut.close();
							outputSocket.close();
						}
					}
					if(msgStrings[0].equals("4")) {

						Log.v(TAG, "message type 4-delete request");

						String key = msgStrings[1];
						String requestorPort = msgStrings[2];
						boolean deleteFlag = false;
						Context context = getContext();
						deleteFlag = context.deleteFile(key);
						serverOut.writeUTF("Key Deleted");
						serverOut.close();
						outputSocket.close();
					}
					if(msgStrings[0].equals("5")){

						Log.v(TAG, "message type 5-delete * request");

						String requestorPort = msgStrings[1];
						boolean deleteFlag = false;
						Context context = getContext();
						String[] myList = context.fileList();
						for (int i = 0; i < myList.length; i++) {
							deleteFlag = context.deleteFile(myList[i]);
						}
						serverOut.writeUTF("Key Deleted");
						serverOut.close();
						outputSocket.close();
					}
					if(msgStrings[0].equals("6")) {

						Log.v(TAG, "message type 6-insert request in case of recovery");

						String key = msgStrings[1];
						String value = msgStrings[2];
						String requestorPort = msgStrings[3];
						int version =0;
						FileOutputStream outputStream;
						Context context = getContext();
						File file = context.getFileStreamPath(key);
						if(file.exists()){
							FileInputStream inputStream;
							inputStream = context.openFileInput(key);
							BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
							String existingValue = null;
							if ((existingValue = in.readLine()) != null) {
								String[] valueArr = existingValue.split("@");
								String currVersion = valueArr[0];
								String currValue = valueArr[1];
								if(Integer.parseInt(currVersion)>Integer.parseInt(value.split("@")[0])) {
									if (!value.contains("@")) {
										value = (Integer.parseInt(currVersion) + 1) + "@" + value;
									}
									else {
										value = existingValue;
									}
								}

							}
							outputStream = context.openFileOutput(key, Context.MODE_PRIVATE);
							outputStream.write(value.getBytes());
							inputStream.close();
						}else {

							if(!value.contains("@")){

								value = (++version) + "@" + value;
							}else{
								//value = (++version) + "@" + value.split("@")[1];
							}
							outputStream = context.openFileOutput(key, Context.MODE_PRIVATE);
							outputStream.write(value.getBytes());
						}
						outputStream.close();
						Log.v(TAG, "inserted: "+key+" "+value);
						try{
							serverOut.writeUTF("Key Inserted");

						}catch(Exception e){
							serverOut.writeUTF(null+"!~!"+null);
							Log.v(TAG,"Exception block from server--->message received " + msgReceived);
							//e.printStackTrace();
						}

						serverOut.close();
						outputSocket.close();
					}
					}catch (IOException e) {
						Log.e(TAG, "Error when listening to client ");
						//e.printStackTrace();
					}
				}

			//return null;
		}
	}
	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getType(Uri uri) {
		// TODO Auto-generated method stub
		return null;
	}

    private String genHash(String input) throws NoSuchAlgorithmException {
        MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
        byte[] sha1Hash = sha1.digest(input.getBytes());
        Formatter formatter = new Formatter();
        for (byte b : sha1Hash) {
            formatter.format("%02x", b);
        }
        return formatter.toString();
    }
}
